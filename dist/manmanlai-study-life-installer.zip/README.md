# 慢慢来 · 学习生活工作台

这是一个无需安装依赖、无需后端即可运行的响应式学习与生活管理应用。直接用现代浏览器打开 `index.html`，或从仓库根目录运行任意静态文件服务器即可体验。

## 功能

- 今日任务进度：创建、编辑、完成 / 恢复和删除待办。
- 一周课程与计划：浏览前后周、新增 / 编辑课程及额外学习安排；显示时间、地点与每周课程总课时，并提示时间冲突。
- 学习记录：使用 25 分钟专注计时器，结束时将时长记入学习记录，也可手动补录。
- 每日习惯和复盘：打卡、添加习惯，保存并随时修改每日复盘。
- 生活费账本：新增、编辑、删除收支，查看月度收支和预算使用情况，并可调整月预算。
- 健康目标：追踪阅读、体重、运动目标及自定义目标，并能自由修改或删除目标。
- 可调节 15、25、50、90 分钟专注时间；对待办、课程、学习记录、习惯、账目和目标进行编辑管理。
- 数据使用浏览器 `localStorage` 本地保存；首次打开会载入可编辑的演示数据。数据仅属于当前浏览器和设备。
- 一键导出 JSON 数据备份；导入之前会验证备份格式，并在覆盖已有数据前要求确认。
- 支持安装为桌面 / 手机 PWA，首次访问时即可缓存应用资源，之后能够离线使用。

## 在线使用与安装

- **在线网址（HTTPS，支持手机和电脑）**：https://leo678910674.github.io/copilot-hack/
- **下载完整 Windows / PWA 安装包**：[manmanlai-study-life-installer.zip](https://github.com/leo678910674/copilot-hack/releases/download/manmanlai-v1.0.0/manmanlai-study-life-installer.zip)。
- **手机安装**：使用手机浏览器打开在线网址，选择“安装应用”或“添加到主屏幕”。iPhone / iPad 请在 Safari 中选择“分享 → 添加到主屏幕”。首次访问需要网络以缓存应用，之后可离线使用。

## 使用

可以直接打开 `index.html`，也可以使用 Python 提供本地静态服务：

```bash
python -m http.server 8000
```

然后访问 `http://localhost:8000`。页面使用原生 HTML、CSS 和 JavaScript，不需要构建步骤。

Windows 用户解压安装包后双击“安装.cmd”即可启动；桌面浏览器也可打开在线网站安装 PWA。手机和平板请打开在线 HTTPS 网站选择浏览器“安装 / 添加到主屏幕”。iPhone / iPad 请通过 Safari 的“分享 → 添加到主屏幕”安装。

## 设计参考

本应用借鉴了同类型开源项目公开介绍的产品理念，没有复制这些项目的代码：

- [Student Study Hub](https://github.com/mayank-dev-15/student-study-hub)：面向学生的离线工具，强调响应式界面、本机 localStorage 与 JSON 数据导入/导出。我们采用本地存储、免账号、JSON 备份与 PWA 离线缓存的组合。
- [Wrindha OS](https://github.com/gongidikalyan/Wrindha-os)：将学习规划、习惯、财务和目标整合为一个学生工作台。其 README 还列出了 Supabase 和 Gemini 环境配置要求；本应用保留整合式信息结构，同时移除外部后端依赖，降低开箱使用门槛。
- [Study Compass](https://github.com/studycompass/study-compass)：以 Pomodoro 和 planner 为核心的轻量学习套件。我们沿用专注计时加日程规划的产品取舍，并补充课程、打卡、财务与健康管理。

参考来源是截至 2026-10-03 阅读的公开仓库 README；关于各项目功能的描述以其 README 为准。
